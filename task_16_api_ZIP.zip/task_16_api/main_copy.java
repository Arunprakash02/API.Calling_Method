package com.example.task_16_api;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class main_copy {

    @SerializedName("ProdId")
    @Expose
    private String prodId;
    @SerializedName("AppId")
    @Expose
    private Integer appId;
    @SerializedName("CompId")
    @Expose
    private Integer compId;
    @SerializedName("BranchId")
    @Expose
    private Integer branchId;
    @SerializedName("ProdType")
    @Expose
    private Integer prodType;
    @SerializedName("UOM")
    @Expose
    private Integer uom;
    @SerializedName("ProdCat")
    @Expose
    private Integer prodCat;
    @SerializedName("ProdSubCat")
    @Expose
    private Object prodSubCat;
    @SerializedName("ProdName")
    @Expose
    private String prodName;
    @SerializedName("CounterName")
    @Expose
    private Object counterName;
    @SerializedName("Brand")
    @Expose
    private Object brand;
    @SerializedName("Size")
    @Expose
    private String size;
    @SerializedName("HSNCode")
    @Expose
    private String hSNCode;
    @SerializedName("PartNumber")
    @Expose
    private String partNumber;
    @SerializedName("Rack")
    @Expose
    private Integer rack;
    @SerializedName("OpeningQty")
    @Expose
    private Double openingQty;
    @SerializedName("QtyBasedPrice")
    @Expose
    private String qtyBasedPrice;
    @SerializedName("QRCode")
    @Expose
    private String qRCode;
    @SerializedName("OnePcQR")
    @Expose
    private String onePcQR;
    @SerializedName("ProdLogo")
    @Expose
    private String prodLogo;
    @SerializedName("AvailableFrom")
    @Expose
    private Object availableFrom;
    @SerializedName("AvailableTo")
    @Expose
    private Object availableTo;
    @SerializedName("StockAvailable")
    @Expose
    private String stockAvailable;
    @SerializedName("TokenAvailable")
    @Expose
    private String tokenAvailable;
    @SerializedName("CancelAvailable")
    @Expose
    private String cancelAvailable;
    @SerializedName("ActiveStatus")
    @Expose
    private String activeStatus;
    @SerializedName("Row")
    @Expose
    private Integer row;
    @SerializedName("TaxId")
    @Expose
    private String taxId;
    @SerializedName("TaxName")
    @Expose
    private String taxName;
    @SerializedName("Cess")
    @Expose
    private Integer cess;
    @SerializedName("UniqueId")
    @Expose
    private String uniqueId;
    @SerializedName("CompName")
    @Expose
    private String compName;
    @SerializedName("BrName")
    @Expose
    private String brName;
    @SerializedName("UomName")
    @Expose
    private String uomName;
    @SerializedName("CategoryName")
    @Expose
    private String categoryName;
    @SerializedName("SubCategoryName")
    @Expose
    private int subCategoryName;
    @SerializedName("BrandName")
    @Expose
    private Object brandName;
    @SerializedName("ProdTypeName")
    @Expose
    private String prodTypeName;
    @SerializedName("InwardDate")
    @Expose
    private String inwardDate;
    @SerializedName("SuppId")
    @Expose
    private String suppId;
    @SerializedName("SuppName")
    @Expose
    private String suppName;
    @SerializedName("Reference")
    @Expose
    private String reference;
    @SerializedName("InwardDtlId")
    @Expose
    private String inwardDtlId;
    @SerializedName("InwardId")
    @Expose
    private String inwardId;
    @SerializedName("AcceptedQty")
    @Expose
    private Double acceptedQty;
    @SerializedName("BalanceQty")
    @Expose
    private Double balanceQty;
    @SerializedName("InwardPrice")
    @Expose
    private Double inwardPrice;
    @SerializedName("IssuedQty")
    @Expose
    private Double issuedQty;
    @SerializedName("MRP")
    @Expose
    private Double mrp;
    @SerializedName("OfferPrice")
    @Expose
    private Double offerPrice;
    @SerializedName("RejectedQty")
    @Expose
    private Double rejectedQty;
    @SerializedName("ReceivedQty")
    @Expose
    private Double receivedQty;
    @SerializedName("SellPrice")
    @Expose
    private Double sellPrice;
    @SerializedName("SpecialPrice")
    @Expose
    private Double specialPrice;
    @SerializedName("WhSalePrice")
    @Expose
    private Double whSalePrice;
    @SerializedName("BatchRef")
    @Expose
    private String batchRef;
    @SerializedName("ModelNumber")
    @Expose
    private Object modelNumber;
    @SerializedName("RejectionReason")
    @Expose
    private String rejectionReason;
    @SerializedName("AutoGenerateQr")
    @Expose
    private String autoGenerateQr;
    @SerializedName("AutoGenerateSingleQr")
    @Expose
    private String autoGenerateSingleQr;
    @SerializedName("OnePcsPrice")
    @Expose
    private Double onePcsPrice;
    @SerializedName("NoOfPcs")
    @Expose
    private Integer noOfPcs;
    @SerializedName("OnePcsAvailable")
    @Expose
    private String onePcsAvailable;
    @SerializedName("TaxPercentage")
    @Expose
    private Double taxPercentage;
    @SerializedName("SalesTaxTypeName")
    @Expose
    private Object salesTaxTypeName;
    @SerializedName("PurchaseTaxTypeName")
    @Expose
    private Object purchaseTaxTypeName;
    @SerializedName("SalesTaxType")
    @Expose
    private Integer salesTaxType;
    @SerializedName("PurchaseTaxType")
    @Expose
    private Integer purchaseTaxType;
    @SerializedName("ProdQtywisePriceDetails")
    @Expose
    private List<Object> prodQtywisePriceDetails;
    @SerializedName("ProdVariantPriceDetails")
    @Expose
    private List<Object> prodVariantPriceDetails;
    @SerializedName("SerialNumber")
    @Expose
    private Object serialNumber;
    @SerializedName("IMEI1")
    @Expose
    private Object imei1;
    @SerializedName("IMEI2")
    @Expose
    private Object imei2;
    @SerializedName("MacId")
    @Expose
    private Object macId;

    public String getProdId() {
        return prodId;
    }

    public void setProdId(String prodId) {
        this.prodId = prodId;
    }

    public Integer getAppId() {
        return appId;
    }

    public void setAppId(Integer appId) {
        this.appId = appId;
    }

    public Integer getCompId() {
        return compId;
    }

    public void setCompId(Integer compId) {
        this.compId = compId;
    }

    public Integer getBranchId() {
        return branchId;
    }

    public void setBranchId(Integer branchId) {
        this.branchId = branchId;
    }

    public Integer getProdType() {
        return prodType;
    }

    public void setProdType(Integer prodType) {
        this.prodType = prodType;
    }

    public Integer getUom() {
        return uom;
    }

    public void setUom(Integer uom) {
        this.uom = uom;
    }

    public Integer getProdCat() {
        return prodCat;
    }

    public void setProdCat(Integer prodCat) {
        this.prodCat = prodCat;
    }

    public Object getProdSubCat() {
        return prodSubCat;
    }

    public void setProdSubCat(Object prodSubCat) {
        this.prodSubCat = prodSubCat;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public Object getCounterName() {
        return counterName;
    }

    public void setCounterName(Object counterName) {
        this.counterName = counterName;
    }

    public Object getBrand() {
        return brand;
    }

    public void setBrand(Object brand) {
        this.brand = brand;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getHSNCode() {
        return hSNCode;
    }

    public void setHSNCode(String hSNCode) {
        this.hSNCode = hSNCode;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public Integer getRack() {
        return rack;
    }

    public void setRack(Integer rack) {
        this.rack = rack;
    }

    public Double getOpeningQty() {
        return openingQty;
    }

    public void setOpeningQty(Double openingQty) {
        this.openingQty = openingQty;
    }

    public String getQtyBasedPrice() {
        return qtyBasedPrice;
    }

    public void setQtyBasedPrice(String qtyBasedPrice) {
        this.qtyBasedPrice = qtyBasedPrice;
    }

    public String getQRCode() {
        return qRCode;
    }

    public void setQRCode(String qRCode) {
        this.qRCode = qRCode;
    }

    public String getOnePcQR() {
        return onePcQR;
    }

    public void setOnePcQR(String onePcQR) {
        this.onePcQR = onePcQR;
    }

    public String getProdLogo() {
        return prodLogo;
    }

    public void setProdLogo(String prodLogo) {
        this.prodLogo = prodLogo;
    }

    public Object getAvailableFrom() {
        return availableFrom;
    }

    public void setAvailableFrom(Object availableFrom) {
        this.availableFrom = availableFrom;
    }

    public Object getAvailableTo() {
        return availableTo;
    }

    public void setAvailableTo(Object availableTo) {
        this.availableTo = availableTo;
    }

    public String getStockAvailable() {
        return stockAvailable;
    }

    public void setStockAvailable(String stockAvailable) {
        this.stockAvailable = stockAvailable;
    }

    public String getTokenAvailable() {
        return tokenAvailable;
    }

    public void setTokenAvailable(String tokenAvailable) {
        this.tokenAvailable = tokenAvailable;
    }

    public String getCancelAvailable() {
        return cancelAvailable;
    }

    public void setCancelAvailable(String cancelAvailable) {
        this.cancelAvailable = cancelAvailable;
    }

    public String getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(String activeStatus) {
        this.activeStatus = activeStatus;
    }

    public Integer getRow() {
        return row;
    }

    public void setRow(Integer row) {
        this.row = row;
    }

    public String getTaxId() {
        return taxId;
    }

    public void setTaxId(String taxId) {
        this.taxId = taxId;
    }

    public String getTaxName() {
        return taxName;
    }

    public void setTaxName(String taxName) {
        this.taxName = taxName;
    }

    public Integer getCess() {
        return cess;
    }

    public void setCess(Integer cess) {
        this.cess = cess;
    }

    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getCompName() {
        return compName;
    }

    public void setCompName(String compName) {
        this.compName = compName;
    }

    public String getBrName() {
        return brName;
    }

    public void setBrName(String brName) {
        this.brName = brName;
    }

    public String getUomName() {
        return uomName;
    }

    public void setUomName(String uomName) {
        this.uomName = uomName;
    }

    public String  getCategoryName() {
        return (String) categoryName;
    }

    public void setCategoryName(Object categoryName) {
        this.categoryName = (String) categoryName;
    }

    public int getSubCategoryName() {
        return subCategoryName;
    }

    public void setSubCategoryName(Object subCategoryName) {
        this.subCategoryName = (int) subCategoryName;
    }

    public Object getBrandName() {
        return brandName;
    }

    public void setBrandName(Object brandName) {
        this.brandName = brandName;
    }

    public String getProdTypeName() {
        return prodTypeName;
    }

    public void setProdTypeName(String prodTypeName) {
        this.prodTypeName = prodTypeName;
    }

    public String getInwardDate() {
        return inwardDate;
    }

    public void setInwardDate(String inwardDate) {
        this.inwardDate = inwardDate;
    }

    public String getSuppId() {
        return suppId;
    }

    public void setSuppId(String suppId) {
        this.suppId = suppId;
    }

    public String getSuppName() {
        return suppName;
    }

    public void setSuppName(String suppName) {
        this.suppName = suppName;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getInwardDtlId() {
        return inwardDtlId;
    }

    public void setInwardDtlId(String inwardDtlId) {
        this.inwardDtlId = inwardDtlId;
    }

    public String getInwardId() {
        return inwardId;
    }

    public void setInwardId(String inwardId) {
        this.inwardId = inwardId;
    }

    public Double getAcceptedQty() {
        return acceptedQty;
    }

    public void setAcceptedQty(Double acceptedQty) {
        this.acceptedQty = acceptedQty;
    }

    public Double getBalanceQty() {
        return balanceQty;
    }

    public void setBalanceQty(Double balanceQty) {
        this.balanceQty = balanceQty;
    }

    public Double getInwardPrice() {
        return inwardPrice;
    }

    public void setInwardPrice(Double inwardPrice) {
        this.inwardPrice = inwardPrice;
    }

    public Double getIssuedQty() {
        return issuedQty;
    }

    public void setIssuedQty(Double issuedQty) {
        this.issuedQty = issuedQty;
    }

    public Double getMrp() {
        return mrp;
    }

    public void setMrp(Double mrp) {
        this.mrp = mrp;
    }

    public Double getOfferPrice() {
        return offerPrice;
    }

    public void setOfferPrice(Double offerPrice) {
        this.offerPrice = offerPrice;
    }

    public Double getRejectedQty() {
        return rejectedQty;
    }

    public void setRejectedQty(Double rejectedQty) {
        this.rejectedQty = rejectedQty;
    }

    public Double getReceivedQty() {
        return receivedQty;
    }

    public void setReceivedQty(Double receivedQty) {
        this.receivedQty = receivedQty;
    }

    public Double getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(Double sellPrice) {
        this.sellPrice = sellPrice;
    }

    public Double getSpecialPrice() {
        return specialPrice;
    }

    public void setSpecialPrice(Double specialPrice) {
        this.specialPrice = specialPrice;
    }

    public Double getWhSalePrice() {
        return whSalePrice;
    }

    public void setWhSalePrice(Double whSalePrice) {
        this.whSalePrice = whSalePrice;
    }

    public String getBatchRef() {
        return batchRef;
    }

    public void setBatchRef(String batchRef) {
        this.batchRef = batchRef;
    }

    public Object getModelNumber() {
        return modelNumber;
    }

    public void setModelNumber(Object modelNumber) {
        this.modelNumber = modelNumber;
    }

    public String getRejectionReason() {
        return rejectionReason;
    }

    public void setRejectionReason(String rejectionReason) {
        this.rejectionReason = rejectionReason;
    }

    public String getAutoGenerateQr() {
        return autoGenerateQr;
    }

    public void setAutoGenerateQr(String autoGenerateQr) {
        this.autoGenerateQr = autoGenerateQr;
    }

    public String getAutoGenerateSingleQr() {
        return autoGenerateSingleQr;
    }

    public void setAutoGenerateSingleQr(String autoGenerateSingleQr) {
        this.autoGenerateSingleQr = autoGenerateSingleQr;
    }

    public Double getOnePcsPrice() {
        return onePcsPrice;
    }

    public void setOnePcsPrice(Double onePcsPrice) {
        this.onePcsPrice = onePcsPrice;
    }

    public Integer getNoOfPcs() {
        return noOfPcs;
    }

    public void setNoOfPcs(Integer noOfPcs) {
        this.noOfPcs = noOfPcs;
    }

    public String getOnePcsAvailable() {
        return onePcsAvailable;
    }

    public void setOnePcsAvailable(String onePcsAvailable) {
        this.onePcsAvailable = onePcsAvailable;
    }

    public Double getTaxPercentage() {
        return taxPercentage;
    }

    public void setTaxPercentage(Double taxPercentage) {
        this.taxPercentage = taxPercentage;
    }

    public Object getSalesTaxTypeName() {
        return salesTaxTypeName;
    }

    public void setSalesTaxTypeName(Object salesTaxTypeName) {
        this.salesTaxTypeName = salesTaxTypeName;
    }

    public Object getPurchaseTaxTypeName() {
        return purchaseTaxTypeName;
    }

    public void setPurchaseTaxTypeName(Object purchaseTaxTypeName) {
        this.purchaseTaxTypeName = purchaseTaxTypeName;
    }

    public Integer getSalesTaxType() {
        return salesTaxType;
    }

    public void setSalesTaxType(Integer salesTaxType) {
        this.salesTaxType = salesTaxType;
    }

    public Integer getPurchaseTaxType() {
        return purchaseTaxType;
    }

    public void setPurchaseTaxType(Integer purchaseTaxType) {
        this.purchaseTaxType = purchaseTaxType;
    }

    public List<Object> getProdQtywisePriceDetails() {
        return prodQtywisePriceDetails;
    }

    public void setProdQtywisePriceDetails(List<Object> prodQtywisePriceDetails) {
        this.prodQtywisePriceDetails = prodQtywisePriceDetails;
    }

    public List<Object> getProdVariantPriceDetails() {
        return prodVariantPriceDetails;
    }

    public void setProdVariantPriceDetails(List<Object> prodVariantPriceDetails) {
        this.prodVariantPriceDetails = prodVariantPriceDetails;
    }

    public Object getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(Object serialNumber) {
        this.serialNumber = serialNumber;
    }

    public Object getImei1() {
        return imei1;
    }

    public void setImei1(Object imei1) {
        this.imei1 = imei1;
    }

    public Object getImei2() {
        return imei2;
    }

    public void setImei2(Object imei2) {
        this.imei2 = imei2;
    }

    public Object getMacId() {
        return macId;
    }

    public void setMacId(Object macId) {
        this.macId = macId;
    }
}
