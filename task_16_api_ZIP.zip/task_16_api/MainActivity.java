package com.example.task_16_api;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements Adapter.john {

    String ans = "";
    private RecyclerView recyclerView;
    private Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recy);
        fetchData();
    }

    private void fetchData() {
        APIclient apiClient = APIclient.getapiClient();
        Call<YourResponseModel> call = apiClient.getapiInterface().getData(82, 134, 2);
        call.enqueue(new Callback<YourResponseModel>() {

            @Override
            public void onResponse(Call<YourResponseModel> call, Response<YourResponseModel> response) {

                if (response.isSuccessful() && response.body() != null) {
                    Log.d("API Corerect", "onResponse: " + "Successs");

                    recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                    Adapter adapter = new Adapter(MainActivity.this, response.body().getData(), MainActivity.this);
                    recyclerView.setAdapter(adapter);
                } else {
                    Log.e("API Error", "Response failed or empty");
                }
            }

            @Override
            public void onFailure(Call<YourResponseModel> call, Throwable t) {
                Log.e("API Error", "Failure: " + t.getMessage());
            }
        });
    }

    @Override
    public void inter(main_copy items,
                      ImageView delete,
                      ImageView edit) {
        String ans = items.getActiveStatus();

        Log.d("GGGGGGG", "join: " + items.getProdName() + "~~~" + items.getSubCategoryName() + "~~~~" + ans);
        delmethod(items, delete, edit, ans);
    }

    public void delmethod(main_copy items,
                          ImageView delete,
                          ImageView edit, String ans) {

        String status = items.getActiveStatus();

        String str = "";

        if (status.equals("A")) {
            str = "D";
        } else {
            str = "A";
        }


        APIclient api = APIclient.getapiClient();
        Call<jsmain> mall = api.getapiInterface().delData("P2-82-134-1", "D", 468);

        mall.enqueue(new Callback<jsmain>() {
            @Override
            public void onResponse(Call<jsmain> call, Response<jsmain> response) {
                if (ans.equals("D")) {
                    edit.setVisibility(View.VISIBLE);
                } else {
                    edit.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(Call<jsmain> call, Throwable t)
            {
                Log.d("solution ", "onFailure: " + "Failed ");

            }
        });
    }


}