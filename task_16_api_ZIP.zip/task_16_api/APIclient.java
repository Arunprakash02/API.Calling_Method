package com.example.task_16_api;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class APIclient {


            private static APIclient apiClient;
            public static Retrofit retrofit;
            private Retrofit retrofitCache ;

            public static String BASE_URL = "http://192.168.1.37:8010/";

            private void APIclientlient() {
                Gson gson = new GsonBuilder().setLenient().create();

                retrofit = new Retrofit.Builder()
                        .baseUrl(BASE_URL)
                        .addConverterFactory(ScalarsConverterFactory.create())
                        .addConverterFactory(GsonConverterFactory.create(gson))
                        .build();

            }


            public static synchronized APIclient getapiClient() {
                apiClient = new APIclient();
                return apiClient;
            }

            public APIinterface getapiInterface() {

                return retrofit.create(APIinterface.class);
            }



}
