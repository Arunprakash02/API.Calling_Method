package com.example.task_16_api;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class YourResponseModel {

    @SerializedName("data")
    @Expose
    private List<main_copy> data;
    @SerializedName("statusCode")
    @Expose
    private Integer statusCode;
    @SerializedName("response")
    @Expose
    private String response;

    public List<main_copy> getData() {
        return data;
    }

    public void setData(List<main_copy> data) {
        this.data = data;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }


}
