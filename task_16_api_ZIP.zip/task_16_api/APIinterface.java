package com.example.task_16_api;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import retrofit2.Call;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Query;


public interface APIinterface {

        @GET("endpoint")
        //main method call - pojo -->  YourResponseModel
        Call<YourResponseModel> getData
                (@Query("CompId")int CompId,
                 @Query("BranchId") int BranchId,
                 @Query("AppId")int AppId);

//        http://192.168.1.37:8010/product?ProdId=P2-82-134-1&ActiveStatus=D&UpdatedBy=468
        @DELETE("product")
        Call<jsmain> delData(
                @Query("ProdId") String ProdId,
                @Query("ActiveStatus") String ActiveStatus,
                @Query("UpdatedBy") int UpdatedBy);



}
