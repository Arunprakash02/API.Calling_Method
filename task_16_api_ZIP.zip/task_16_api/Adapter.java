package com.example.task_16_api;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.Viewholder> {

    Context context;
    // pojo  value class -->  main_copy
    List<main_copy> items;

    //step -- 2 implement the interface (john -- class name )
    private john Arun;

    public Adapter(Context context, List<main_copy> items, john Arun) {
        this.context = context;
        this.items = items;
        this.Arun = Arun;
    }


    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // vH classs call                        context                         recycler xml class calling
        return new Viewholder(LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_main, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.Viewholder holder, int position) {
        main_copy mc = items.get(position);
        holder.com_name.setText(mc.getCompName());
        holder.pr_name.setText(mc.getProdName());
        holder.cate_name.setText(mc.getCategoryName());
        holder.subcate_name.setText(mc.getSubCategoryName());
        holder.mrp.setText(mc.getMrp().intValue());

        //step - 4  check the status
        if (mc.getActiveStatus().equals("A"))
            holder.edit.setVisibility(View.VISIBLE);
        else
            holder.edit.setVisibility(View.GONE);

        //step - 3
        holder.delete.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
             {
                Arun.inter(mc, holder.delete, holder.edit);
            }
        });
    }

    @Override
    public int getItemCount() {

        return items.size();
    }

    /*step :-1*/
//    public interface john {
//
//        void inter(main_copy items, ImageView delete, ImageView edit);
//    }

    public class Viewholder extends RecyclerView.ViewHolder {

        TextView com_name, pr_name, cate_name, subcate_name, mrp;

        ImageView delete, edit;

        public Viewholder(@NonNull View itemView) {
            super(itemView);
            com_name = itemView.findViewById(R.id.com_name);
            pr_name = itemView.findViewById(R.id.pr_name);
            cate_name = itemView.findViewById(R.id.cate_name);
            subcate_name = itemView.findViewById(R.id.subcate_name);
            mrp = itemView.findViewById(R.id.mrp);


            // Delete mtehod ID
            delete = itemView.findViewById(R.id.delete);
            edit = itemView.findViewById(R.id.edit);

        }
    }

    /*step :-1create interface */
    public interface john {

        void inter(main_copy items, ImageView delete, ImageView edit);
    }


}



