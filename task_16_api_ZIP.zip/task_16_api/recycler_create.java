package com.example.task_16_api;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class recycler_create extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_create);


    }
}